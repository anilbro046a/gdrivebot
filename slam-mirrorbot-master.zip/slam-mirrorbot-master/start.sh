./aria.sh; python3 -m bot
